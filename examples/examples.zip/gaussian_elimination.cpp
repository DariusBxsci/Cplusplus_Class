#include <stdio.h>
#include "gaussian_elimination.h"

int main() {

    double mat[] = { 2,1,-1,  -3,-1,2,  -2,1,2 };
    double vec[] = { 8,-11,-3 };

    gsl_vector *solution;
    solution = bx::gaussian_elimination( mat, vec, 3 );

    gsl_vector_fprintf (stdout, solution, "%g");

    gsl_vector_free (solution);

    return 0;
}
