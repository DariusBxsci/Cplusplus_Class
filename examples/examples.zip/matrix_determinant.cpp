#include <iostream>
#include "matrix_determinant.h"

int main() {

    double mat[] = { 2,1,-1,  -3,-1,2,  -2,1,2 };

    double determinant = bx::matrix_determinant( mat, 3 );

    std::cout << "Determinant is: " << determinant << std::endl;

    return 0;
}
