#include <gsl/gsl_linalg.h>

#ifndef BX_MATRIX_DETERMINANT_H
#define BX_MATRIX_DETERMINANT_H

namespace bx {

    double matrix_determinant(double* A, const int mat_size) {

        double det;
        int signum;
        gsl_permutation *p = gsl_permutation_alloc(mat_size);

        //create a temporary matrix on which to perform LU decomposition
        gsl_matrix tmpA;
        gsl_matrix_view m = gsl_matrix_view_array (A, mat_size, mat_size);
        tmpA = m.matrix;

        //perform Lu decomposition and find the determinant
        gsl_linalg_LU_decomp(&tmpA , p , &signum);
        det = gsl_linalg_LU_det(&tmpA , signum);

        //free up permutation and matrix pointers
        gsl_permutation_free(p);        
        //gsl_matrix_free(m.matrix);
        
        return det;
    }

}

#endif