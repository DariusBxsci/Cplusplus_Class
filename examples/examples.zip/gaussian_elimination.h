#include <stdio.h>
#include <gsl/gsl_linalg.h>

#ifndef BX_GAUSSIAN_ELIMINATION_H
#define BX_GAUSSIAN_ELIMINATION_H

namespace bx {

    gsl_vector* gaussian_elimination (double* a_data, double* b_data, int mat_size) {

        //a_data is the matrix describing the linear system
        //b_data is a vector of values on the right hand side of the equations in the system
        //mat_size is the length of the matrix and vector

        /* Example input:
        double a_data[] = { 0.18, 0.60, 0.57, 0.96,
                            0.41, 0.24, 0.99, 0.58,
                            0.14, 0.30, 0.97, 0.66,
                            0.51, 0.13, 0.19, 0.85 };

        double b_data[] = { 1.0, 2.0, 3.0, 4.0 };
        */

        //allocate space for input matrix, input vector, and result vector
        gsl_matrix_view m = gsl_matrix_view_array (a_data, mat_size, mat_size);
        gsl_vector_view b = gsl_vector_view_array (b_data, mat_size);
        gsl_vector *x = gsl_vector_alloc (mat_size);

        //solve the system
        int s;
        gsl_permutation * p = gsl_permutation_alloc (mat_size);
        gsl_linalg_LU_decomp (&m.matrix, p, &s);
        gsl_linalg_LU_solve (&m.matrix, p, &b.vector, x);

        //print the results
        //gsl_vector_fprintf (stdout, x, "%g");

        //make sure to free allocated memory!
        gsl_permutation_free (p);

        //since we are returning the result vector we can't free it yet
        //gsl_vector_free (x);

        return x;
    }

}

#endif